<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title><?php echo $this->table_name?></title>
    <link href="../../public/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<!-- <body onload="window.print()"> -->
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
<?php
if ($this->table_name == 'Sbas Barang')
{
    echo "<h2>Laporan Stock Barang</h2>";
}
elseif ($this->table_name == 'Sbas Masuk')
{
    echo "<h2>Laporan Barang Masuk</h2>";
}
?>
                <hr>
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-12">
                <table class="xcrud-list table table-striped table-condensed table-hover table-bordered">
                    <thead>
                        <?php echo $this->render_grid_head(); ?>
                    </thead>
                    <tbody>
                        <?php echo $this->render_grid_body(); ?>
                    </tbody>
                    <tfoot>
                        <?php echo $this->render_grid_footer(); ?>
                    </tfoot>
                </table>
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-4 col-md-offset-8">
                <p>Banjarmasin, <?php echo date('d-F-Y'); ?></p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4 col-md-offset-8">
                <p>Direktur</p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4 col-md-offset-8">
                <p>&nbsp;</p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4 col-md-offset-8">
                <p>&nbsp;</p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4 col-md-offset-8">
                <p><b><i>Nama Direktur</i></b></p>
            </div>
        </div>
    </div>
    
</body>
</html>